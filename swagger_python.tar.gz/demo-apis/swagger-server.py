from pyramid.traversal import DefaultRootFactory
from pyramid.request import Request
from pyramid.httpexceptions import exception_response
from openapi_core.schema.exceptions import OpenAPIError
from openapi_core.schema.exceptions import OpenAPIMappingError
from pyramid.view import view_config
from waitress import serve
from pyramid.config import Configurator
import sys

import typing as t

def extract_error(err: OpenAPIError, field_name: str = None) -> t.Dict[str, str]:
    output = {"message": str(err), "exception": err.__class__.__name__}

    if getattr(err, "name", None) is not None:
        field_name = err.name
    if getattr(err, "property_name", None) is not None:
        field_name = err.property_name
    if field_name is None:
        if isinstance(getattr(err, "original_exception", None), OpenAPIMappingError):
            return extract_error(err.original_exception, field_name)
    if field_name is not None:
        output.update({"field": field_name})
    return output

@view_config(name="openapi_validation_error")
def openapi_validation_error(
    context: DefaultRootFactory, request: Request
) -> exception_response:
    errors = [extract_error(err) for err in request.openapi_validated.errors]
    return exception_response(400, json_body=errors)

if __name__=='__main__':
    with Configurator() as config:
        config.set_default_permission(False)
        config.include("pyramid_openapi3")
        print(sys.argv[1])
        config.pyramid_openapi3_spec(
            sys.argv[1]
        )
        #config.pyramid_openapi3_validation_error_view("openapi_validation_error")
        config.pyramid_openapi3_add_explorer()
        config.scan('.')
        app = config.make_wsgi_app()
    serve(app, host='0.0.0.0', port=int(sys.argv[2]))
